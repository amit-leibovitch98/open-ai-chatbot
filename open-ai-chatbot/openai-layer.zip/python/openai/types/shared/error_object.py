# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import Union, Optional
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["ErrorObject", "Misalignment", "MisalignmentSteer"]


class MisalignmentSteer(BaseModel):
    """An optional public continuation instruction."""

    message: str
    """The public continuation instruction."""


class Misalignment(BaseModel):
    detailed_explanation: Optional[str] = None
    """The public explanation for this block."""

    error_type: Union[
        str,
        Literal[
            "potentially_unintended_data_transfer",
            "potentially_unintended_data_access",
            "potentially_unintended_destructive_activity",
            "other",
        ],
        None,
    ] = None
    """An optional classification; clients must accept additional values."""

    review_target: Optional[str] = None
    """
    An opaque target for explicitly continuing this review, or null when
    unavailable.
    """

    steer: Optional[MisalignmentSteer] = None
    """An optional public continuation instruction."""


class ErrorObject(BaseModel):
    code: Optional[str] = None

    message: str

    param: Optional[str] = None

    type: str

    misalignment: Optional[Misalignment] = None
