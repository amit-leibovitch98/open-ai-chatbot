# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import Dict
from typing_extensions import TypeAlias

__all__ = ["Metadata"]

Metadata: TypeAlias = Dict[str, str]
