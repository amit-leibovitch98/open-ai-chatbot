# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from ..._models import BaseModel

__all__ = ["BetaResponseRefusalDeltaEvent", "Agent"]


class Agent(BaseModel):
    """The agent that owns this multi-agent streaming event."""

    agent_name: str
    """The canonical name of the agent that produced this item."""


class BetaResponseRefusalDeltaEvent(BaseModel):
    """Emitted when there is a partial refusal text."""

    content_index: int
    """The index of the content part that the refusal text is added to."""

    delta: str
    """The refusal text that is added."""

    item_id: str
    """The ID of the output item that the refusal text is added to."""

    output_index: int
    """The index of the output item that the refusal text is added to."""

    sequence_number: int
    """The sequence number of this event."""

    type: Literal["response.refusal.delta"]
    """The type of the event. Always `response.refusal.delta`."""

    agent: Optional[Agent] = None
    """The agent that owns this multi-agent streaming event."""
