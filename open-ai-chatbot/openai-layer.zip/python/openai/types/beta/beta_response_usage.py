# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import Optional

from ..._models import BaseModel

__all__ = [
    "BetaResponseUsage",
    "InputTokensDetails",
    "InputTokensDetailsCacheWriteTokensDetails",
    "OutputTokensDetails",
]


class InputTokensDetailsCacheWriteTokensDetails(BaseModel):
    ttl_12h_tokens: int
    """The number of input tokens written with 12-hour retention."""

    ttl_30m_tokens: int
    """The number of input tokens written with 30-minute retention."""


class InputTokensDetails(BaseModel):
    """A detailed breakdown of the input tokens."""

    cache_write_tokens: int
    """The number of input tokens that were written to the cache."""

    cached_tokens: int
    """
    The number of tokens that were retrieved from the cache.
    [More on prompt caching](https://developers.openai.com/api/docs/guides/prompt-caching).
    """

    cache_write_tokens_details: Optional[InputTokensDetailsCacheWriteTokensDetails] = None


class OutputTokensDetails(BaseModel):
    """A detailed breakdown of the output tokens."""

    reasoning_tokens: int
    """The number of reasoning tokens."""


class BetaResponseUsage(BaseModel):
    """
    Represents token usage details including input tokens, output tokens,
    a breakdown of output tokens, and the total tokens used.
    """

    input_tokens: int
    """The number of input tokens."""

    input_tokens_details: InputTokensDetails
    """A detailed breakdown of the input tokens."""

    output_tokens: int
    """The number of output tokens."""

    output_tokens_details: OutputTokensDetails
    """A detailed breakdown of the output tokens."""

    total_tokens: int
    """The total number of tokens used."""
