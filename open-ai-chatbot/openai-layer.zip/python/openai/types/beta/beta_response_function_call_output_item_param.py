# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Union
from typing_extensions import TypeAlias

from .beta_response_input_file_content_param import BetaResponseInputFileContentParam
from .beta_response_input_text_content_param import BetaResponseInputTextContentParam
from .beta_response_input_image_content_param import BetaResponseInputImageContentParam

__all__ = ["BetaResponseFunctionCallOutputItemParam"]

BetaResponseFunctionCallOutputItemParam: TypeAlias = Union[
    BetaResponseInputTextContentParam, BetaResponseInputImageContentParam, BetaResponseInputFileContentParam
]
