# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import Dict, List, Union, Optional
from typing_extensions import Literal, Annotated, TypeAlias

from ..._utils import PropertyInfo
from ..._models import BaseModel
from .beta_custom_tool import BetaCustomTool
from .beta_computer_tool import BetaComputerTool
from .beta_function_tool import BetaFunctionTool
from .beta_web_search_tool import BetaWebSearchTool
from .beta_apply_patch_tool import BetaApplyPatchTool
from .beta_file_search_tool import BetaFileSearchTool
from .beta_tool_search_tool import BetaToolSearchTool
from .beta_function_shell_tool import BetaFunctionShellTool
from .beta_web_search_preview_tool import BetaWebSearchPreviewTool
from .beta_computer_use_preview_tool import BetaComputerUsePreviewTool
from .beta_container_network_policy_disabled import BetaContainerNetworkPolicyDisabled
from .beta_tool_search_output_namespace_tool import BetaToolSearchOutputNamespaceTool
from .beta_container_network_policy_allowlist import BetaContainerNetworkPolicyAllowlist

__all__ = [
    "BetaResponseToolSearchOutputItemParam",
    "Tool",
    "ToolMcp",
    "ToolMcpAllowedTools",
    "ToolMcpAllowedToolsMcpToolFilter",
    "ToolMcpRequireApproval",
    "ToolMcpRequireApprovalMcpToolApprovalFilter",
    "ToolMcpRequireApprovalMcpToolApprovalFilterAlways",
    "ToolMcpRequireApprovalMcpToolApprovalFilterNever",
    "ToolCodeInterpreter",
    "ToolCodeInterpreterContainer",
    "ToolCodeInterpreterContainerCodeInterpreterToolAuto",
    "ToolCodeInterpreterContainerCodeInterpreterToolAutoNetworkPolicy",
    "ToolProgrammaticToolCalling",
    "ToolImageGeneration",
    "ToolImageGenerationInputImageMask",
    "ToolImageGenerationSvg",
    "ToolImageGenerationSvgReasoning",
    "ToolLocalShell",
    "Agent",
]


class ToolMcpAllowedToolsMcpToolFilter(BaseModel):
    """A filter object to specify which tools are allowed."""

    read_only: Optional[bool] = None
    """Indicates whether or not a tool modifies data or is read-only.

    If an MCP server is
    [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
    it will match this filter.
    """

    tool_names: Optional[List[str]] = None
    """List of allowed tool names."""


ToolMcpAllowedTools: TypeAlias = Union[List[str], ToolMcpAllowedToolsMcpToolFilter, None]


class ToolMcpRequireApprovalMcpToolApprovalFilterAlways(BaseModel):
    """A filter object to specify which tools are allowed."""

    read_only: Optional[bool] = None
    """Indicates whether or not a tool modifies data or is read-only.

    If an MCP server is
    [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
    it will match this filter.
    """

    tool_names: Optional[List[str]] = None
    """List of allowed tool names."""


class ToolMcpRequireApprovalMcpToolApprovalFilterNever(BaseModel):
    """A filter object to specify which tools are allowed."""

    read_only: Optional[bool] = None
    """Indicates whether or not a tool modifies data or is read-only.

    If an MCP server is
    [annotated with `readOnlyHint`](https://modelcontextprotocol.io/specification/2025-06-18/schema#toolannotations-readonlyhint),
    it will match this filter.
    """

    tool_names: Optional[List[str]] = None
    """List of allowed tool names."""


class ToolMcpRequireApprovalMcpToolApprovalFilter(BaseModel):
    """Specify which of the MCP server's tools require approval.

    Can be
    `always`, `never`, or a filter object associated with tools
    that require approval.
    """

    always: Optional[ToolMcpRequireApprovalMcpToolApprovalFilterAlways] = None
    """A filter object to specify which tools are allowed."""

    never: Optional[ToolMcpRequireApprovalMcpToolApprovalFilterNever] = None
    """A filter object to specify which tools are allowed."""


ToolMcpRequireApproval: TypeAlias = Union[ToolMcpRequireApprovalMcpToolApprovalFilter, Literal["always", "never"], None]


class ToolMcp(BaseModel):
    """
    Give the model access to additional tools via remote Model Context Protocol
    (MCP) servers. [Learn more about MCP](https://developers.openai.com/api/docs/guides/tools-connectors-mcp).
    """

    server_label: str
    """A label for this MCP server, used to identify it in tool calls."""

    type: Literal["mcp"]
    """The type of the MCP tool. Always `mcp`."""

    allowed_callers: Optional[List[Literal["direct", "programmatic"]]] = None
    """The tool invocation context(s)."""

    allowed_tools: Optional[ToolMcpAllowedTools] = None
    """List of allowed tool names or a filter object."""

    authorization: Optional[str] = None
    """
    An OAuth access token that can be used with a remote MCP server, either with a
    custom MCP server URL or a service connector. Your application must handle the
    OAuth authorization flow and provide the token here.
    """

    connector_id: Optional[
        Literal[
            "connector_dropbox",
            "connector_gmail",
            "connector_googlecalendar",
            "connector_googledrive",
            "connector_microsoftteams",
            "connector_outlookcalendar",
            "connector_outlookemail",
            "connector_sharepoint",
        ]
    ] = None
    """Identifier for service connectors, like those available in ChatGPT.

    One of `server_url`, `connector_id`, or `tunnel_id` must be provided. Learn more
    about service connectors
    [here](https://developers.openai.com/api/docs/guides/tools-connectors-mcp#connectors).

    This field is deprecated for models released after September 1, 2026. Use
    `server_url` to connect to a remote MCP server, or `tunnel_id` to connect
    through a Secure MCP Tunnel.

    Currently supported `connector_id` values are:

    - Dropbox: `connector_dropbox`
    - Gmail: `connector_gmail`
    - Google Calendar: `connector_googlecalendar`
    - Google Drive: `connector_googledrive`
    - Microsoft Teams: `connector_microsoftteams`
    - Outlook Calendar: `connector_outlookcalendar`
    - Outlook Email: `connector_outlookemail`
    - SharePoint: `connector_sharepoint`
    """

    defer_loading: Optional[bool] = None
    """Whether this MCP tool is deferred and discovered via tool search."""

    headers: Optional[Dict[str, str]] = None
    """Optional HTTP headers to send to the MCP server.

    Use for authentication or other purposes.
    """

    require_approval: Optional[ToolMcpRequireApproval] = None
    """Specify which of the MCP server's tools require approval."""

    server_description: Optional[str] = None
    """Optional description of the MCP server, used to provide more context."""

    server_url: Optional[str] = None
    """The URL for the MCP server.

    One of `server_url`, `connector_id`, or `tunnel_id` must be provided.
    """

    tunnel_id: Optional[str] = None
    """The Secure MCP Tunnel ID to use instead of a direct server URL.

    One of `server_url`, `connector_id`, or `tunnel_id` must be provided.
    """


ToolCodeInterpreterContainerCodeInterpreterToolAutoNetworkPolicy: TypeAlias = Annotated[
    Union[BetaContainerNetworkPolicyDisabled, BetaContainerNetworkPolicyAllowlist], PropertyInfo(discriminator="type")
]


class ToolCodeInterpreterContainerCodeInterpreterToolAuto(BaseModel):
    """Configuration for a code interpreter container.

    Optionally specify the IDs of the files to run the code on.
    """

    type: Literal["auto"]
    """Always `auto`."""

    file_ids: Optional[List[str]] = None
    """An optional list of uploaded files to make available to your code."""

    memory_limit: Optional[Literal["1g", "4g", "16g", "64g"]] = None
    """The memory limit for the code interpreter container."""

    network_policy: Optional[ToolCodeInterpreterContainerCodeInterpreterToolAutoNetworkPolicy] = None
    """Network access policy for the container."""


ToolCodeInterpreterContainer: TypeAlias = Union[str, ToolCodeInterpreterContainerCodeInterpreterToolAuto]


class ToolCodeInterpreter(BaseModel):
    """A tool that runs Python code to help generate a response to a prompt."""

    container: ToolCodeInterpreterContainer
    """The code interpreter container.

    Can be a container ID or an object that specifies uploaded file IDs to make
    available to your code, along with an optional `memory_limit` setting.
    """

    type: Literal["code_interpreter"]
    """The type of the code interpreter tool. Always `code_interpreter`."""

    allowed_callers: Optional[List[Literal["direct", "programmatic"]]] = None
    """The tool invocation context(s)."""


class ToolProgrammaticToolCalling(BaseModel):
    type: Literal["programmatic_tool_calling"]
    """The type of the tool. Always `programmatic_tool_calling`."""


class ToolImageGenerationInputImageMask(BaseModel):
    """Optional mask for inpainting.

    Contains `image_url`
    (string, optional) and `file_id` (string, optional).
    """

    file_id: Optional[str] = None
    """File ID for the mask image."""

    image_url: Optional[str] = None
    """Base64-encoded mask image."""


class ToolImageGenerationSvgReasoning(BaseModel):
    """Reasoning effort for SVG authoring.

    When omitted, uses the author model's default in both Images and Responses.
    """

    effort: Optional[Literal["none", "minimal", "low", "medium", "high", "xhigh", "max"]] = None
    """Controls how much effort the model should spend on reasoning for this request."""


class ToolImageGenerationSvg(BaseModel):
    """SVG author model settings.

    Requires `output_format` to be `svg`.
    When SVG model selection is enabled, omitting this object uses the
    outer response model. Otherwise, the default SVG author is used and
    explicit model overrides are unavailable.
    """

    model: Optional[str] = None

    reasoning: Optional[ToolImageGenerationSvgReasoning] = None
    """Reasoning effort for SVG authoring.

    When omitted, uses the author model's default in both Images and Responses.
    """


class ToolImageGeneration(BaseModel):
    """A tool that generates images using the GPT image models."""

    type: Literal["image_generation"]
    """The type of the image generation tool. Always `image_generation`."""

    action: Optional[Literal["generate", "edit", "auto"]] = None
    """Whether to generate a new image or edit an existing image. Default: `auto`."""

    background: Optional[Literal["transparent", "opaque", "auto"]] = None
    """Allows to set transparency for the background of the generated image(s).

    Must be one of `transparent`, `opaque`, or `auto` (default value). When `auto`
    is used, the model will automatically determine the best background for the
    image.

    `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
    snapshots, support `opaque` and `transparent` backgrounds. Transparent
    backgrounds are available for supported GPT Image models. For `gpt-image-2` and
    `gpt-image-2-2026-04-21`, this support is in preview. When using `transparent`,
    set the output format to `png` or `webp`.
    """

    complexity: Optional[Literal["low", "medium", "high"]] = None
    """
    Computation spent planning the image, independently of rendering quality.
    Overrides the outer response's `reasoning.effort` for image generation. When
    omitted, inherits a supported outer reasoning effort or uses the image model's
    configured default. For SVG output, controls the reference image, not the SVG
    author's reasoning.
    """

    frame_count: Optional[int] = None
    """Number of GIF frames. Requires `output_format` to be `gif`. Default: 9."""

    frame_duration_ms: Optional[int] = None
    """
    Duration of each GIF frame in milliseconds, rounded to 10 ms. Requires
    `output_format` to be `gif`. Default: 200.
    """

    input_fidelity: Optional[Literal["high", "low"]] = None
    """
    Control how much effort the model will exert to match the style and features,
    especially facial features, of input images. Supports `high` and `low` on
    `gpt-image-1.5`; `gpt-image-1-mini` supports only `low`. For `gpt-image-2`, omit
    this parameter. Defaults to `low` on supported models.
    """

    input_image_mask: Optional[ToolImageGenerationInputImageMask] = None
    """Optional mask for inpainting.

    Contains `image_url` (string, optional) and `file_id` (string, optional).
    """

    model: Union[
        str,
        Literal[
            "gpt-image-1",
            "gpt-image-1-mini",
            "gpt-image-2",
            "gpt-image-2-2026-04-21",
            "gpt-image-2.5-sunburst",
            "gpt-image-2.5-sunburst-2026-09-08",
            "gpt-image-2.5-flare",
            "gpt-image-2.5-flare-2026-09-08",
            "gpt-image-2.6-sunburst",
            "gpt-image-2.6-flare",
            "gpt-image-1.5",
            "chatgpt-image-latest",
        ],
        None,
    ] = None
    """The image generation model to use.

    One of `gpt-image-1-mini`, `gpt-image-1.5`, `gpt-image-2`,
    `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
    `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`,
    `gpt-image-2.5-flare-2026-09-08`, `gpt-image-2.6-sunburst`,
    `gpt-image-2.6-flare`, or `chatgpt-image-latest`. Default: `gpt-image-2`.

    `gpt-image-1` was shut down on October 23, 2026. Use `gpt-image-2.5-sunburst` or
    `gpt-image-2.5-flare` instead.

    Deprecated values:

    - "gpt-image-1": GPT Image 1 was shut down on October 23, 2026. Use
      gpt-image-2.5-sunburst or gpt-image-2.5-flare instead.
    """

    moderation: Optional[Literal["auto", "low"]] = None
    """Moderation level for the generated image. Default: `auto`."""

    output_compression: Optional[int] = None
    """Compression level for the output image. Default: 100."""

    output_format: Optional[Literal["png", "webp", "jpeg", "gif", "svg"]] = None
    """The output format of the generated image.

    One of `png`, `webp`, `jpeg`, `gif`, or `svg`. Default: `png`. GIF and SVG
    output require a model that supports the selected format. GIF output does not
    support partial image streaming (`partial_images` greater than `0`),
    `input_image_mask`, or custom `output_compression`. Responses lifecycle events
    can still be streamed for GIF output.
    """

    partial_images: Optional[int] = None
    """
    Number of partial images to generate in streaming mode, from 0 (default value)
    to 3.
    """

    quality: Optional[Literal["low", "medium", "high", "xhigh", "max", "auto"]] = None
    """The quality of the generated image.

    The GPT image models support `low`, `medium`, and `high`.
    `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare`, including their `2026-09-08`
    snapshots, also support `xhigh` and `max`. Default: `auto`.
    """

    size: Union[str, Literal["1024x1024", "1024x1536", "1536x1024", "auto"], None] = None
    """The size of the generated images.

    For `gpt-image-2`, `gpt-image-2-2026-04-21`, `gpt-image-2.5-sunburst`,
    `gpt-image-2.5-sunburst-2026-09-08`, `gpt-image-2.5-flare`, and
    `gpt-image-2.5-flare-2026-09-08`, arbitrary resolutions are supported as
    `WIDTHxHEIGHT` strings, for example `1536x864`. Width and height must both be
    divisible by 16 and the requested aspect ratio must be between 1:3 and 3:1.
    Resolutions above `2560x1440` are experimental, and the maximum supported
    resolution is `3840x2160`. The requested size must also satisfy the model's
    current pixel and edge limits. The standard sizes `1024x1024`, `1536x1024`, and
    `1024x1536` are supported by the GPT image models; `auto` is supported for
    models that allow automatic sizing.
    """

    svg: Optional[ToolImageGenerationSvg] = None
    """SVG author model settings.

    Requires `output_format` to be `svg`. When SVG model selection is enabled,
    omitting this object uses the outer response model. Otherwise, the default SVG
    author is used and explicit model overrides are unavailable.
    """


class ToolLocalShell(BaseModel):
    """A tool that allows the model to execute shell commands in a local environment."""

    type: Literal["local_shell"]
    """The type of the local shell tool. Always `local_shell`."""


Tool: TypeAlias = Annotated[
    Union[
        BetaFunctionTool,
        BetaFileSearchTool,
        BetaComputerTool,
        BetaComputerUsePreviewTool,
        BetaWebSearchTool,
        ToolMcp,
        ToolCodeInterpreter,
        ToolProgrammaticToolCalling,
        ToolImageGeneration,
        ToolLocalShell,
        BetaFunctionShellTool,
        BetaCustomTool,
        BetaToolSearchOutputNamespaceTool,
        BetaToolSearchTool,
        BetaWebSearchPreviewTool,
        BetaApplyPatchTool,
    ],
    PropertyInfo(discriminator="type"),
]


class Agent(BaseModel):
    """The agent that produced this item."""

    agent_name: str
    """The canonical name of the agent that produced this item."""


class BetaResponseToolSearchOutputItemParam(BaseModel):
    tools: List[Tool]
    """The loaded tool definitions returned by the tool search output."""

    type: Literal["tool_search_output"]
    """The item type. Always `tool_search_output`."""

    id: Optional[str] = None
    """The unique ID of this tool search output."""

    agent: Optional[Agent] = None
    """The agent that produced this item."""

    call_id: Optional[str] = None
    """The unique ID of the tool search call generated by the model."""

    execution: Optional[Literal["server", "client"]] = None
    """Whether tool search was executed by the server or by the client."""

    status: Optional[Literal["in_progress", "completed", "incomplete"]] = None
    """The status of the tool search output."""
