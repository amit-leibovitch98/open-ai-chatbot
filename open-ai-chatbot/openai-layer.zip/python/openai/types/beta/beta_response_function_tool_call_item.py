# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from typing import Optional
from typing_extensions import Literal

from .beta_response_function_tool_call import BetaResponseFunctionToolCall

__all__ = ["BetaResponseFunctionToolCallItem"]


class BetaResponseFunctionToolCallItem(BetaResponseFunctionToolCall):
    """A tool call to run a function.

    See the
    [function calling guide](https://developers.openai.com/api/docs/guides/function-calling) for more information.
    """

    id: str  # ty: ignore[invalid-mutable-override]
    """The unique ID of the function tool call."""

    status: Literal["in_progress", "completed", "incomplete"]  # ty: ignore[invalid-mutable-override]
    """The status of the item.

    One of `in_progress`, `completed`, or `incomplete`. Populated when items are
    returned via API.
    """

    created_by: Optional[str] = None
    """The identifier of the actor that created the item."""
