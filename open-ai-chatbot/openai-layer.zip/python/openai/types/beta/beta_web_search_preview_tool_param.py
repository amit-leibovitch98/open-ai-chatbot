# File generated from our OpenAPI spec by Castiron. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import List, Optional
from typing_extensions import Literal, Required, TypedDict

__all__ = ["BetaWebSearchPreviewToolParam", "UserLocation"]


class UserLocation(TypedDict, total=False):
    """The approximate location of the user.

    If omitted or null, defaults to the United States. To avoid this fallback, pass `{"type": "approximate"}` without location fields. To localize results, provide the relevant location fields.
    """

    type: Required[Literal["approximate"]]
    """The type of location approximation. Always `approximate`."""

    city: Optional[str]
    """Free text input for the city of the user, e.g. `San Francisco`."""

    country: Optional[str]
    """
    The two-letter [ISO country code](https://en.wikipedia.org/wiki/ISO_3166-1) of
    the user, e.g. `US`.
    """

    region: Optional[str]
    """Free text input for the region of the user, e.g. `California`."""

    timezone: Optional[str]
    """
    The [IANA timezone](https://timeapi.io/documentation/iana-timezones) of the
    user, e.g. `America/Los_Angeles`.
    """


class BetaWebSearchPreviewToolParam(TypedDict, total=False):
    """This tool searches the web for relevant results to use in a response.

    Learn more about the [web search tool](https://developers.openai.com/api/docs/guides/tools-web-search).
    """

    type: Required[Literal["web_search_preview", "web_search_preview_2025_03_11"]]
    """The type of the web search tool.

    One of `web_search_preview` or `web_search_preview_2025_03_11`.
    """

    search_content_types: List[Literal["text", "image"]]

    search_context_size: Literal["low", "medium", "high"]
    """High level guidance for the amount of context window space to use for the
    search.

    One of `low`, `medium`, or `high`. `medium` is the default.
    """

    user_location: Optional[UserLocation]
    """The approximate location of the user.

    If omitted or null, defaults to the United States. To avoid this fallback, pass
    `{"type": "approximate"}` without location fields. To localize results, provide
    the relevant location fields.
    """
